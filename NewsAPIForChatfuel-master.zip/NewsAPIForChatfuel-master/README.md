# News API for Chatfuel - Get article suggestions for the topic you want from this API.

A very simple API that leverages the [News API](https://newsapi.org/) and provides you with suggestions for articles to read in the form of a Facebook Messenger Gallery.

# Deploy
[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)